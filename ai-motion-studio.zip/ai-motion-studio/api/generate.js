// POST /api/generate — يرسل المهمة إلى fal.ai (قائمة انتظار) ويعيد روابط المتابعة.
const hits = new Map();
const MODEL = () => process.env.FAL_MODEL || 'fal-ai/kling-video/v2.1/standard/image-to-video';

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'bad_input' });
  const key = process.env.FAL_KEY;
  if (!key) return res.status(500).json({ error: 'no_key' });

  // حد اختياري للطلبات (مضبوط من البيئة؛ 0 = بدون حد). الذاكرة هنا لكل نسخة خادم، لذا هو حماية تقريبية.
  const limit = parseInt(process.env.RATE_LIMIT_PER_HOUR || '0', 10);
  if (limit > 0) {
    const ip = String(req.headers['x-forwarded-for'] || 'x').split(',')[0].trim();
    const now = Date.now();
    const arr = (hits.get(ip) || []).filter(t => now - t < 36e5);
    if (arr.length >= limit) return res.status(429).json({ error: 'rate' });
    arr.push(now); hits.set(ip, arr);
  }

  const { image, prompt, negativePrompt, duration, cfgScale } = req.body || {};
  if (typeof image !== 'string' || image.length > 4e6 || !/^data:image\/(jpeg|png|webp);base64,/.test(image))
    return res.status(400).json({ error: 'bad_input' });
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 2000)
    return res.status(400).json({ error: 'bad_input' });

  const body = {
    prompt: prompt.trim(),
    image_url: image,
    duration: ['5', '10'].includes(String(duration)) ? String(duration) : '5',
    cfg_scale: Math.min(1, Math.max(0, Number(cfgScale) || 0.5)),
  };
  if (typeof negativePrompt === 'string' && negativePrompt.trim()) body.negative_prompt = negativePrompt.trim().slice(0, 1000);

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await fetch('https://queue.fal.run/' + MODEL(), {
        method: 'POST',
        headers: { Authorization: 'Key ' + key, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (r.status >= 500 && attempt === 0) { await new Promise(s => setTimeout(s, 1200)); continue; }
      const d = await r.json().catch(() => ({}));
      if (!r.ok) {
        const error = r.status === 401 || r.status === 403 ? 'auth' : r.status === 429 ? 'quota' : r.status === 422 ? 'bad_input' : 'provider';
        return res.status(r.status === 429 ? 429 : 502).json({ error });
      }
      return res.json({ statusUrl: d.status_url, responseUrl: d.response_url });
    } catch (e) {
      if (attempt === 1) return res.status(502).json({ error: 'provider' });
    }
  }
};

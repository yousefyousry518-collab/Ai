// GET /api/status?s=<status_url>&r=<response_url> — يتابع المهمة ويعيد رابط الفيديو عند الاكتمال.
const ok = u => { try { const x = new URL(u); return x.protocol === 'https:' && x.hostname === 'queue.fal.run'; } catch { return false; } };

module.exports = async (req, res) => {
  const key = process.env.FAL_KEY;
  const { s, r } = req.query || {};
  if (!key) return res.status(500).json({ error: 'no_key' });
  if (!ok(s) || !ok(r)) return res.status(400).json({ error: 'bad_input' }); // يمنع استخدام الخادم كوسيط لروابط أخرى
  const h = { Authorization: 'Key ' + key };
  try {
    const sr = await fetch(s, { headers: h });
    if (!sr.ok) return res.status(502).json({ error: 'provider' });
    const st = await sr.json();
    if (st.status !== 'COMPLETED')
      return res.json({ status: st.status === 'IN_PROGRESS' ? 'processing' : 'queued', position: st.queue_position ?? null });
    const rr = await fetch(r, { headers: h });
    const out = await rr.json().catch(() => ({}));
    const url = out && out.video && out.video.url;
    if (!rr.ok || !url) return res.json({ status: 'failed', error: 'failed' });
    res.json({ status: 'done', videoUrl: url });
  } catch (e) {
    res.status(502).json({ error: 'provider' });
  }
};
